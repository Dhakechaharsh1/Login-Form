<?php
// include the database configuration file and start a session
include('config/dbconfig.php');
session_start();

$error = "";

// check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // retrieve the email and password from the POST request
    $email = $_POST['email'];
    $password = $_POST['password'];

    // check if both fields are empty
    if (empty($email) || empty($password)) {
        $error = 'Both fields are required.';
    } else {
        // check if the email is a valid email format
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please enter a valid email address.';
        } else {
            // check if the email and password fields are not empty
            if (!empty($email) && !empty($password)) {
                // prepare a SELECT statement to retrieve the user with the given email and password
                $stmt = $conn->prepare("SELECT * FROM users WHERE email = :email AND password = :password");
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':password', $password);
                $stmt->execute();

                // if the SELECT statement returns a single row, set the session variables and redirect to member.php
                if ($stmt->rowCount() == 1) {
                    $user = $stmt->fetch(PDO::FETCH_ASSOC);
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['first_name'] = $user['first_name'];
                    $_SESSION['last_name'] = $user['last_name'];
                    header("Location: member.php");
                    exit();
                } else {
                    // if the SELECT statement does not return a single row, display an error message
                    $error = "Invalid email or password.";
                }
            }
        }
    }
}
?>

<!-- begin HTML -->
<!DOCTYPE html>
<html>

<head>
    <title>Welcome</title>
    <link rel="stylesheet" href="CSS/index.css">
</head>

<body>

    <?php include('templates/header.php'); ?>
    <h1>Welcome to my website!</h1>

    <!-- if the user is not logged in, display a login form -->
    <?php if (!isset($_SESSION["id"])) { ?>
        <form method="post">
            <label>Email:</label>
            <input type="email" name="email" required><br><br>
            <label>Password:</label>
            <input type="password" name="password" required><br><br>
            <button type="submit" name="login">Login</button>
        </form>
        <!-- display the error message if there is one -->
        <?php if ($error): ?>
            <p class="error-message"><?php echo $error; ?></p>
        <?php endif; ?>
        <p><a href="register.php">Don't have an account? Register here.</a></p>
    <!-- if the user is already logged in, display a message to that effect -->
    <?php } else { ?>
        <p>You are already logged in.</p>
    <?php } ?>
    <?php include('templates/footer.php'); ?>
</body>

</html>
