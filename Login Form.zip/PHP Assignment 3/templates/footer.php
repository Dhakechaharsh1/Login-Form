<link rel="stylesheet" href="CSS/footer.css" >
</div>
<!-- End div.main-contnet -->
</div> <!-- End div#container -->
<footer>Developed By: Harsh Dhakecha, Sarthak Nasit, Preet Patel</footer>
</body>

</html>