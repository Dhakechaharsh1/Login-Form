<!DOCTYPE HTML> <!-- Using full HTML 5 -->
<html>

<head>
    <meta charset="utf-8">
    <title>PHP Final Assignment</title>
    <link rel="stylesheet" href="CSS/header.css">
</head>

<body>
    <div id="container">
        <header id="banner">
            <h2>Final Assignment</h2>
        </header>
        <div id="nav">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="member.php">Member</a></li>
                <li><a href="register.php">Register</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </div>
        <div class="main-content">