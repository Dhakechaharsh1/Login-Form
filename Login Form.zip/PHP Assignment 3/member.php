<?php
// start a session
session_start();

// if the user is not logged in, redirect them to the index.php page
if (!isset($_SESSION["email"])) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Welcome</title>
    <link rel="stylesheet" href="CSS/member.css" >
</head>
<body>
    <?php include('templates/header.php'); ?>
	<!-- display a welcome message with the user's first and last name -->
	<h1>Welcome, <?php echo $_SESSION["first_name"] . " " . $_SESSION["last_name"]; ?></h1>
	<!-- display the user's email address -->
	<p>Your email address is: <?php echo $_SESSION["email"]; ?></p>
	<!-- provide a link to log out -->
	<a href="logout.php">Logout</a>
    <?php include('templates/footer.php'); ?>
