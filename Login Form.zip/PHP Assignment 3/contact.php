<?php
// start a session
session_start();

$error = '';
$sent = false;

// check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // retrieve the full name, email, and message from the POST request
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $message = trim($_POST['message']);

    // check if any fields are empty
    if (empty($full_name) || empty($email) || empty($message)) {
        $error = "All fields are required.";
    } else {
        // set up the email parameters and send the email
        $to = "admin@example.com";
        $subject = "Contact Form Submission";
        $headers = "From: " . $email . "\r\n";
        $headers .= "Reply-To: " . $email . "\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
        $body = "<html><body>";
        $body .= "<p>Name: " . $full_name . "</p>";
        $body .= "<p>Email: " . $email . "</p>";
        $body .= "<p>Message: " . nl2br($message) . "</p>";
        $body .= "</body></html>";

        // check if the email was sent successfully
        if (mail($to, $subject, $body, $headers)) {
            $sent = true;
        } else {
            $error = "There was an error sending your message. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact Us</title>
    <link rel="stylesheet" href="CSS/contact.css" >
</head>
<body>
<?php include('templates/header.php'); ?>
    <h1>Contact Us</h1>
    
    <!-- if the email was sent successfully, display a success message -->
    <?php if ($sent): ?>
        <p>Thank you for your message! We will get back to you as soon as possible.</p>
    <!-- if the email was not sent successfully, display an error message -->
    <?php else: ?>
        <?php if (!empty($error)): ?>
            <p><?= $error ?></p>
        <?php endif; ?>

        <!-- display the contact form -->
        <form action="contact.php" method="post">
            <label for="full_name">Full Name:</label>
            <input type="text" name="full_name" id="full_name" required>
            <br>
            <label for="email">Email:</label>
            <input type="email" name="email" id="email" required>
            <br>
            <label for="message">Message:</label>
            <textarea name="message" id="message" rows="5" required></textarea>
            <br>
            <input type="submit" value="Send">
        </form>
    <?php endif; ?>
    <?php include('templates/footer.php'); ?>

</body>
</html>
