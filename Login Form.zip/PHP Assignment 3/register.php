<?php
// include the database configuration file and start a session
include('config/dbconfig.php');
session_start();

// if the request method is POST, attempt to register the user
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // retrieve the first name, last name, email, and password from the POST request
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // check if any fields are empty
    if (empty($first_name) || empty($last_name) || empty($email) || empty($password)) {
        $error = 'All fields are required.';
    } else {
        // check if the email is valid
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please enter a valid email address.';
        } else {
            // check if the email already exists in the database
            $sql = "SELECT * FROM users WHERE email = :email";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':email', $email);
            $stmt->execute();

            // if the email does not already exist, hash the password and add the user to the database
            if ($stmt->rowCount() == 0) {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $sql = "INSERT INTO users (first_name, last_name, email, password) VALUES (:first_name, :last_name, :email, :password)";
                $stmt = $conn->prepare($sql);
                $stmt->bindParam(':first_name', $first_name);
                $stmt->bindParam(':last_name', $last_name);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':password', $hashed_password);

                // if the user is added to the database successfully, start a session and redirect to the member.php page
                if ($stmt->execute()) {
                    $_SESSION['email'] = $email;
                    $_SESSION['first_name'] = $first_name;
                    $_SESSION['last_name'] = $last_name;
                    header('Location: member.php');
                    exit();
                } else {
                    $error = 'Registration failed. Please try again.';
                }
            } else {
                $error = 'Email already exists.';
            }
        }
    }
}

?>

<!DOCTYPE html>
<html>

<head>
    <title>Register</title>
    <link rel="stylesheet" href="CSS/register.css" >
</head>

<body>
    <?php include('templates/header.php'); ?>
    <h1>Register</h1>
    <!-- if there is an error, display it -->
    <?php if (isset($error)) { ?>
        <p><?php echo $error; ?></p>
    <?php } ?>
    <!-- display the registration form -->
    <form method="post" action="">
        <label for="first_name">First Name:</label>
        <input type="text" id="first_name" name="first_name"><br>
        <label for="last_name">Last Name:</label>
        <input type="text" id="last_name" name="last_name"><br>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email"><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password"><br>
        <input type="submit" value="Submit">
</form>
<?php include('templates/footer.php'); ?>
